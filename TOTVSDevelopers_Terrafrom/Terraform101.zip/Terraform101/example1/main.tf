# Terraform and Azure Provider configuration

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~>4.0"
      ##any azurerm version, from 4.0 or above
    }
  }
}

provider "azurerm" {
  features {}
  #tenant_id & subscription_id are not declared, so DEFAULT values associated to login will be assumed here

}

resource "azurerm_resource_group" "rg" {
  name     = "myownresourcegroup1989"
  location = "East Us"
}

