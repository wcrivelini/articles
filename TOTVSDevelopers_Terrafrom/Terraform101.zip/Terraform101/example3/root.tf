# Terraform and Azure Provider configuration

terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
      version = "~>4.0"
      ##any azurerm version, from 4.0 or above
    }
  }
}

provider "azurerm" {
  features {}
  #tenant_id & subscription_id are not declared, so DEFAULT values associated to login will be assumed here

}


#ti recognize parameter associated to current session
data "azurerm_client_config" "current" {}






module "ResourceGroup" {
  source                                = "../modules/ResourceGroup"
  rg_name                               = local.rg_name
  location                              = var.location
  tags                                  = local.tags
}

module "cosmosdbaccount" {
  source                                = "../modules/CosmosDB-Acct"
  cosmosdb_accountname                  = local.cosmosdb_accountname
  location                              = var.location
  rg_name                               = local.rg_name
  cosmosdb_offer_type                   = var.cosmosdb_offer_type
  cosmosdb_kind                         = var.cosmosdb_kind
  cosmosdb_consistency_level            = var.cosmosdb_consistency_level
  cosmosdb_replica_location             = var.cosmosdb_replica_location
  cosmosdb_failover_priority            = var.cosmosdb_failover_priority
  tags                                  = local.tags     

  depends_on = [module.ResourceGroup]               
} 

module "cosmosdbdatabase" {
  source                                = "../modules/CosmosDB-DB"
  cosmosdb_dbsqlname                    = var.cosmosdb_dbsqlname
  rg_name                               = local.rg_name
  cosmosdb_accountname                  = local.cosmosdb_accountname
  cosmosdb_throughput                   = var.cosmosdb_throughput

  depends_on = [module.cosmosdbaccount]
}

module "databricks" {
  source                                = "../modules/Databricks"
  databricks_name                       = local.databricks_name
  rg_name                               = local.rg_name
  location                              = var.location
  databricks_sku                        = var.databricks_sku
  tags                                  = local.tags   

  depends_on = [module.ResourceGroup]
}


module "keyvault" {
  source                                = "../modules/Key-Vault"
  keyvault_name                         = local.keyvault_name
  location                              = var.location
  rg_name                               = local.rg_name
  keyvault_encryption                   = var.keyvault_encryption 
  keyvault_tenantid                     = data.azurerm_client_config.current.tenant_id
  keyvault_retention                    = var.keyvault_retention 
  keyvault_purgeprotection              = var.keyvault_purgeprotection
  keyvault_sku                          = var.keyvault_sku

  tags                                  = local.tags   

  depends_on = [module.ResourceGroup]

}


module "mssqlserver" {
  source                                = "../modules/SQL-Server"
  sql_name                              = local.sql_name
  rg_name                               = local.rg_name
  location                              = var.location
  sql_version                           = var.sql_version
  sql_login                             = var.sql_login
  sql_loginpass                         = var.sql_loginpass
  sql_tls                               = var.sql_tls
  aadadmin_name                         = var.aadadmin_name 
  aadadmin_oid                          = var.aadadmin_oid

  tags                                  = local.tags

  depends_on = [module.ResourceGroup]
}

module "mssqldatabase" {
  source                                = "../modules/SQL-DB"
  mssqldatabase_name                    = var.mssqldatabase_name
  mssqldatabase_serverid                = module.mssqlserver.sqlserver_id
  mssqldatabase_collation               = var.mssqldatabase_collation
  mssqldatabase_license                 = var.mssqldatabase_license
  mssqldatabase_maxsizegb               = var.mssqldatabase_maxsizegb
  mssqldatabase_sku                     = var.mssqldatabase_sku
  tags                                  = local.tags 
  depends_on = [module.mssqlserver]
}


module "storageaccount" {
  source                                = "../modules/StorageAccount"
  stoacct_name                          = local.stoacct_name
  rg_name                               = local.rg_name
  location                              = var.location
  stoacct_tier                          = var.stoacct_tier
  stoacct_replication                   = var.stoacct_replication
  stoacct_kind                          = var.stoacct_kind 
  stoacct_hierarchical_namespace        = var.stoacct_hierarchical_namespace 
  tags                                  = local.tags

  depends_on = [module.ResourceGroup]
}


module "storageaccountcontainer" {
  source                                = "../modules/StorageAccountContainer"
  stoacctcont_name                      = var.stoacctcont_name
  stoacct_name                          = local.stoacct_name
  stoacctcont_access                    = var.stoacctcont_access

  depends_on = [module.storageaccount]
}



module "datalakegen2account" {  
  source                                = "../modules/StorageAccount"
  stoacct_name                          = local.dtlkg2acct_name
  rg_name                               = local.rg_name
  location                              = var.location
  stoacct_tier                          = var.dtlkg2_tier
  stoacct_replication                   = var.dtlkg2_replication
  stoacct_kind                          = var.dtlkg2_kind 
  stoacct_hierarchical_namespace        = var.dtlkg2_hierarchical_namespace 

  tags                                  = local.tags

  depends_on = [module.ResourceGroup]
}


module "datalakegen2filesystem" {
  source                                = "../modules/DataLakeGen2FileSystem"
  dtlkg2filesystem_name                 = var.dtlkg2filesystem_name
  dtlkg2_acctid                         = module.datalakegen2account.id

  depends_on = [module.datalakegen2account]
}


module "datalakegen2path" {
  source                                = "../modules/DataLakeGen2Path"
  dtlkg2path_name                       = var.dtlkg2path_name
  dtlkg2filesystem_name                 = var.dtlkg2filesystem_name
  dtlkg2_acctid                         = module.datalakegen2account.id
  dtlkg2path_resource                   = var.dtlkg2path_resource
  
  depends_on = [module.datalakegen2filesystem]
}
  

# SYNAPSE WORKSPACE REQUISITES
# Storage Account + Data Lake Filesystem
module "syndatalakegen2account" {  
  source                                = "../modules/StorageAccount"
  stoacct_name                          = local.syndtlkg2acct_name
  rg_name                               = local.rg_name
  location                              = var.location
  stoacct_tier                          = var.syndtlkg2_tier
  stoacct_replication                   = var.syndtlkg2_replication
  stoacct_kind                          = var.syndtlkg2_kind 
  stoacct_hierarchical_namespace        = var.syndtlkg2_hierarchical_namespace 

  tags                                  = local.tags

  depends_on = [module.ResourceGroup]
}

module "syndatalakegen2filesystem" {
  source                                = "../modules/DataLakeGen2"
  dtlkg2_name                           = var.syndtlkg2filesystem_name
  dtlkg2_acctid                         = module.syndatalakegen2account.id

  depends_on = [module.syndatalakegen2account]
}


module "synapseworkspace" {
  source                                = "../modules/SynapseWorkspace"
  synapsewkspc_name                     = local.synapsewkspc_name
  location                              = var.location
  rg_name                               = local.rg_name
  synapsewkspc_datalakeid               = module.syndatalakegen2filesystem.id
  synapsewkspc_sqladmin_login           = var.synapsewkspc_sqladmin_login 
  synapsewkspc_sqladmin_pass            = var.synapsewkspc_sqladmin_pass

  
  synapsewkspc_type                     = var.synapsewkspc_type

  tags                                  = local.tags

  depends_on = [module.datalakegen2filesystem]
}


module "synapseaadadmin" {
  source                                = "../modules/SynapseAadAdmin"
  synaad_wrkspcid                       = module.synapseworkspace.id
  synaad_login                          = var.aadadmin_name 
  synaad_oid                            = var.aadadmin_oid
  synaad_tid                            = data.azurerm_client_config.current.tenant_id

  depends_on = [module.synapseworkspace]
}



module "synapsesqlpool" {
  source                                = "../modules/SynapseSQLPool"
  synsqlpool_name                       = var.synsqlpool_name
  synsqlpool_wrkspcid                   = module.synapseworkspace.id
  synsqlpool_sku                        = var.synsqlpool_sku
  synsqlpool_mode                       = var.synsqlpool_mode

  depends_on = [module.synapseworkspace]
}

