output "name" {
  description = "The name of the resoruce created."
  value       = azurerm_databricks_workspace.databricks.name
}

output "id" {
  description = "The id of the resource created."
  value       = azurerm_databricks_workspace.databricks.id
}


