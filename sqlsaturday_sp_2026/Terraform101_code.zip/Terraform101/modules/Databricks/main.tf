resource "azurerm_databricks_workspace" "databricks" {
  name                                = var.databricks_name
  resource_group_name                 = var.rg_name
  location                            = var.location
  sku                                 = var.databricks_sku

  tags                                  = var.tags
}
