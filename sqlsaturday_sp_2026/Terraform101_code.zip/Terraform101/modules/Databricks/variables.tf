variable "rg_name" {
  type  = string 
  description = "The resource group name."
}
variable "location" {
  type  = string 
  description = "The region were the resource will be deployed."
}

variable "databricks_name" {
  type  = string 
  description = "Databricks workspace name."
}  

variable "databricks_sku" {
  type  = string 
  description = "type Standard, Premium or Trial"
}

variable "tags" {
    type  = map(string) 
    description = "tags related to project"
}
