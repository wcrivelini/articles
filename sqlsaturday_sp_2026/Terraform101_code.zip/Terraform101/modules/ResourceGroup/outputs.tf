output "newResourceGroupName" {
  value = azurerm_resource_group.ResourceGroup.name
}

output "id" {
  value = azurerm_resource_group.ResourceGroup.id
}

#output "tenant_id" {
#  value = azurerm_resource_group.ResourceGroup.tenant_id
#}
