#reference https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/resource_group
resource "azurerm_resource_group" "ResourceGroup" {
    name              	     = var.rg_name
    location       		    	 = var.location
    tags                   	 = var.tags
  }