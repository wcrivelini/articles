variable "rg_name" {
    type  = string 
    description = "resource group name"
}

variable "location" {
    type  = string 
    description = "code related to Azure Region"
}    


variable "tags" {
    type  = map(string) 
    description = "tags related to project"
}