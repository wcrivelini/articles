resource "azurerm_storage_account" "storageaccount" {
  name                                  = var.stoacct_name
  resource_group_name                   = var.rg_name
  location                              = var.location
  account_tier                          = var.stoacct_tier
  account_replication_type              = var.stoacct_replication
  account_kind                          = var.stoacct_kind 
  is_hns_enabled                        = var.stoacct_hierarchical_namespace

  tags                                  = var.tags
}