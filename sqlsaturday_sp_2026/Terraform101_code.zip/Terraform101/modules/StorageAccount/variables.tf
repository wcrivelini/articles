variable "rg_name" {
  type        = string 
  description = "The resource group name."
}
variable "location" {
  type        = string 
  description = "The region were the resource will be deployed."
}

variable "stoacct_name" {
  type        = string 
  description = "resource name."
}  

variable "stoacct_tier" {
  type        = string 
  description = "tier must be Standard or Premium"
}

variable "stoacct_replication" {
  type        = string 
  description = "Type of replication. Valid values are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS"
}

variable "stoacct_kind" {
  type        = string 
  description = "Kind of Storage Account. Default is StoraV2, other values are BlobStorage, BlockBlobStorage, FileStorage, and Storage"
  
}

variable "stoacct_hierarchical_namespace" {
  type        = string 
  description = "Defines if Storage Account will use Hierarchical Namespace"
}
 
variable "tags" {
    type        = map(string) 
    description = "tags related to project"
}
