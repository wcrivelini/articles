#https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/synapse_workspace_aad_admin

resource "azurerm_synapse_workspace_aad_admin" "synapseaadadmin" {
  synapse_workspace_id = var.synaad_wrkspcid
  login                = var.synaad_login
  object_id            = var.synaad_oid
  tenant_id            = var.synaad_tid

}
