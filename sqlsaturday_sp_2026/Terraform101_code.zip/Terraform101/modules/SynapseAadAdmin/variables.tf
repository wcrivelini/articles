
variable "synaad_wrkspcid" {
  type  = string 
  description = "ID of the associated synapse workspace."
}  

variable "synaad_login" {
  type  = string 
  description = "AAD admin login"
}

variable "synaad_oid" {
  type  = string
  description = "AAD ID for workspace administrator"
 } 

variable "synaad_tid" {
  type  = string
  description = "Tenant ID of the AAD login"
  # https://docs.microsoft.com/en-us/azure/cosmos-db/consistency-levels
 } 


