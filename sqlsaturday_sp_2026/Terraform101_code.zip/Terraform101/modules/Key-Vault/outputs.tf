

output "id" {
  description = "The id of the resource created."
  value       = azurerm_key_vault.keyvault.id
}


