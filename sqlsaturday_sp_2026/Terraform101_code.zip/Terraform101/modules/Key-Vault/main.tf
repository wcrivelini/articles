# https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/key_vault
resource "azurerm_key_vault" "keyvault" {
  name                                  = var.keyvault_name
  location                              = var.location
  resource_group_name                   = var.rg_name
  enabled_for_disk_encryption           = var.keyvault_encryption #(true/false)
  tenant_id                             = var.keyvault_tenantid
  soft_delete_retention_days            = var.keyvault_retention #7
  purge_protection_enabled              = var.keyvault_purgeprotection #false
  sku_name                              = var.keyvault_sku

  tags                                  = var.tags
}
