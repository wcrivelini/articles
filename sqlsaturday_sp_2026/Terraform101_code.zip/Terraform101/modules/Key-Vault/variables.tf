variable "rg_name" {
  type  = string 
  description = "The resource group name."
}
variable "location" {
  type  = string 
  description = "The region were the resource will be deployed."
}

variable "keyvault_name" {
  type  = string 
  description = "The Key Vault name."
}  

variable "keyvault_encryption" {
  type  = string 
  description = "encryption activated or not (true/false)"
}

variable "keyvault_tenantid" {
  type  = string 
  description = "tenant associated to key vault (AAD)"
}
 
variable "keyvault_retention" {
  type  = number 
  description = "Number of days to retain deleted secrets/keys"
 }  
variable "keyvault_purgeprotection" {
  type  = string 
  description = "Failover priority in case of crash. Must be a value equal or less than number of replicas minus 1"
 }  

variable "keyvault_sku" {
  type  = string
  description = "Type of Key Vault"

 } 


variable "tags" {
    type  = map(string) 
    description = "tags related to project"
}
  
  
  
  
  
  