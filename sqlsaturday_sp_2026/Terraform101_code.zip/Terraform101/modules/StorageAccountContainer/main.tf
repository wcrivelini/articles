resource "azurerm_storage_container" "storageaccountcontainer" {
  name                                  = var.stoacctcont_name
  storage_account_name                  = var.stoacct_name
  container_access_type                 = var.stoacctcont_access
}
