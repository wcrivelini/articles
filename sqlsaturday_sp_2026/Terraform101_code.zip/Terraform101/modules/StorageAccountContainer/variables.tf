variable "stoacctcont_name" {
  type  = string 
  description = "Storage account container name."
}  

variable "stoacct_name" {
  type  = string 
  description = "Storage account name"
}

variable "stoacctcont_access" {
  type  = string 
  description = "Container access type. Valid values are blob, container or private. Defaults to private."
}
