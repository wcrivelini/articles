#https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path

resource "azurerm_storage_data_lake_gen2_filesystem" "datalakegen2filesystem" {
  name                                  = var.dtlkg2filesystem_name
  storage_account_id                    = var.dtlkg2_acctid

  properties = {

  }
}