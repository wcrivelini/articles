variable "dtlkg2filesystem_name" {
  type  = string 
  description = "Filesystem name"
}  

variable "dtlkg2_acctid" {
  type  = string 
  description = "id of the storage account associated to the data lake"
}
