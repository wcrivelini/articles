output "name" {
  description = "The name of the resoruce created."
  value       = azurerm_storage_account.storageaccount.name
}

output "id" {
  description = "The id of the resource created."
  value       = azurerm_storage_account.storageaccount.id
}
