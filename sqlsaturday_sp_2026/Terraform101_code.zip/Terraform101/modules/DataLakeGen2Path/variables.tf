variable "dtlkg2path_name" {
  type       = string 
  description = "resource name."
}  

variable "dtlkg2filesystem_name" {
  type        = string 
  description = "id of the storage account associated to the data lake"
}


variable "dtlkg2path_resource" {
  type        = string 
  description = "type of resource to Data Lake Gen2 Path. Today only value is directory"
  default     = "directory"
}

variable "dtlkg2_acctid" {
  type  = string 
  description = "id of the storage account associated to the data lake"
}