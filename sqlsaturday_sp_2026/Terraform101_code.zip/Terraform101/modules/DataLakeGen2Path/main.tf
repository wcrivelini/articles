#https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path

resource "azurerm_storage_data_lake_gen2_path" "datalakegen2path" {
  path                                  = var.dtlkg2path_name
  filesystem_name                       = var.dtlkg2filesystem_name
  storage_account_id                    = var.dtlkg2_acctid
  resource                              = var.dtlkg2path_resource

}