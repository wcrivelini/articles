output "id" {
  description = "The id of the resource created."
  value       = azurerm_storage_data_lake_gen2_path.datalakegen2path.id
}
