variable "rg_name" {
  type  = string 
  description = "The resource group name."
}

variable "location" {
  type  = string 
  description = "The region were the resource will be deployed."
}

variable "tags" {
    type  = map(string) 
    description = "tags related to project"
}


variable "synapsewkspc_name" {
  type  = string 
  description = "resource name."
}  

variable "synapsewkspc_datalakeid" {
  type  = string 
  description = "Data Lake GEN2 id"
}

variable "synapsewkspc_sqladmin_login" {
  type  = string 
  description = "SQL admin login (SQL Pools)"
}

variable "synapsewkspc_sqladmin_pass" {
  type  = string 
  description = "SQL admin password (SQL Pools)"
 }  

variable "synapsewkspc_type" {
  type  = string
  description = "Type of Managed Service Identity used by Synapse Workspace. Valid values: SystemAssigned"
 }


