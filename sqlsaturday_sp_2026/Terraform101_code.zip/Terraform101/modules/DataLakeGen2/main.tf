resource "azurerm_storage_data_lake_gen2_filesystem" "datalakegen2" {
  name                                  = var.dtlkg2_name
  storage_account_id                    = var.dtlkg2_acctid
}