output "name" {
  description = "The name of the resoruce created."
  value       = azurerm_storage_data_lake_gen2_filesystem.datalakegen2.name
}

output "id" {
  description = "The id of the resource created."
  value       = azurerm_storage_data_lake_gen2_filesystem.datalakegen2.id
}
