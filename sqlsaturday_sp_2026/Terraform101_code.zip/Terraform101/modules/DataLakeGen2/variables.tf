variable "dtlkg2_name" {
  type  = string 
  description = "resource name."
}  

variable "dtlkg2_acctid" {
  type  = string 
  description = "id of the storage account associated to the data lake"
}
