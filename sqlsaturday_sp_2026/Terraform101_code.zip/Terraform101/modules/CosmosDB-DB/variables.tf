variable "rg_name" {
  type  = string 
  description = "The resource group name."
}

variable "cosmosdb_accountname" {
  type  = string 
  description = "The Cosmos DB account name."
}  

variable "cosmosdb_dbsqlname" {
  type  = string 
  description = "name of the database (SQL API)"
}

variable "cosmosdb_throughput" {
  type  = string 
  description = "database throughput"
}
 
