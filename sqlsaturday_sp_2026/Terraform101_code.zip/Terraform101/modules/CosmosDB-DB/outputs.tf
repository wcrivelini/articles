output "name" {
  description = "The name of the resoruce created."
  value       = var.cosmosdb_dbsqlname
}


output "id" {
  description = "The id of the resource created."
  value       = azurerm_cosmosdb_sql_database.cosmosdbdatabase.id
}

