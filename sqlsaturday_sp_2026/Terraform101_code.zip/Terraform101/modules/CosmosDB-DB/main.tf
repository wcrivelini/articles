resource "azurerm_cosmosdb_sql_database" "cosmosdbdatabase" {
  name                                  = var.cosmosdb_dbsqlname
  resource_group_name                   = var.rg_name
  account_name                          = var.cosmosdb_accountname
  throughput                            = var.cosmosdb_throughput
}

