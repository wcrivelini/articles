resource "azurerm_mssql_server" "mssqlserver" {
  name                                  = var.sql_name
  resource_group_name                   = var.rg_name
  location                              = var.location
  version                               = var.sql_version
  administrator_login                   = var.sql_login
  administrator_login_password          = var.sql_loginpass
  minimum_tls_version                   = var.sql_tls

  azuread_administrator {
    login_username                      = var.aadadmin_name 
    object_id                           = var.aadadmin_oid
  }

  tags                                  = var.tags
}

