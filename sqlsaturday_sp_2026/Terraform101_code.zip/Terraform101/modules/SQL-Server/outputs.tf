output "name" {
  description = "The name of the resoruce created."
  value       = azurerm_mssql_server.mssqlserver.name
}

output "sqlserver_id" {
  description = "The id of the resource created."
  value       = azurerm_mssql_server.mssqlserver.id
}

