
locals {

  rgname1 = format("%s-%s-%s-%s-02", var.shortprovider, var.shortlocation1, var.environment, var.resourceIdentifier)
  rgname2 = format("%s-%s-%s-%s-02", var.shortprovider, var.shortlocation2, var.environment, var.resourceIdentifier)


  tag = {
    company      = var.company
    project      = "${var.company}-${var.project}"
    costcenter   = var.costcenter
    environment  = var.environment
  }  
}