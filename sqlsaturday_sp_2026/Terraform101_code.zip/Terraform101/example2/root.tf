# Terraform and Azure Provider configuration
terraform {
  required_providers {
    azurerm = {
      source = "hashicorp/azurerm"
      version = "~>3.0"
      ##any azurerm version, from 3.0.0 or above
    }
  }
}
provider "azurerm" {
  features {}
}

module "ResourceGroup1" {
  source      = "../modules/ResourceGroup"
  rg_name   	  = local.rgname1
  location    = var.location1
  tags         = local.tag
}

module "ResourceGroup2" {
  source      = "../modules/ResourceGroup"
  rg_name   	  = local.rgname2
  location    = var.location2
  tags         = local.tag
}
