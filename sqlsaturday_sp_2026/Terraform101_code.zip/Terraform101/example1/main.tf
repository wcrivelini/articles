# Terraform and Azure Provider configuration

terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~>3.0"
      ##any azurerm version, from 3.0.0 or above
    }
  }
}

provider "azurerm" {
  features {}
  #tenant_id & subscription_id are not declared, so DEFAULT values associated to login will be assumed here

}

resource "azurerm_resource_group" "rg" {
  name     = "myownresourcegroup1900"
  location = "East Us"
}

