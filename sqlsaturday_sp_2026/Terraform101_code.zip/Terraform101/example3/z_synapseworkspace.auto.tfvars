synapsewkspc_identifier             = "syn"
synapsewkspc_sqladmin_login         = "wwiadmin"
synapsewkspc_sqladmin_pass          = "wuu1@dm1n"
synapsewkspc_type                   = "SystemAssigned"