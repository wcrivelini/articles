#https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path
syndtlkg2_identifier      = "syndtlkg2"
syndtlkg2_tier            = "Premium"
syndtlkg2_replication     = "LRS"
syndtlkg2_kind            = "BlockBlobStorage"
syndtlkg2_hierarchical_namespace = "true"
