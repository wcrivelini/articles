#https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path
dtlkg2filesystem_name          = "datalake"