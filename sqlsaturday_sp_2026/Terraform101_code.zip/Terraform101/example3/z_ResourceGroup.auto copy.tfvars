
resourcegroup_identifier= "rg"
location                = "southcentralus"
shortlocation           = "ussc"