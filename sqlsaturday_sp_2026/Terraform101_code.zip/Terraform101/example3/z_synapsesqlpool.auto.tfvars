synsqlpool_name                         = "whiterabbit"
synsqlpool_sku                          = "DW100c"
synsqlpool_mode                         = "Default"