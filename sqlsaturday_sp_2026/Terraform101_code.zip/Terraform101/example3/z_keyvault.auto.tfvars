keyvault_identifier         = "kv"
keyvault_encryption         = "true"
keyvault_retention          = "7"
keyvault_purgeprotection    = "false"
keyvault_sku                = "standard"

