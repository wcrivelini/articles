#https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path
dtlkg2_identifier      = "dtlkg2"
dtlkg2_tier            = "Premium"
dtlkg2_replication     = "LRS"
dtlkg2_kind            = "BlockBlobStorage"
dtlkg2_hierarchical_namespace = "true"
