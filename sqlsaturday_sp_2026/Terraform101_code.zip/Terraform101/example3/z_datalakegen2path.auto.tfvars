#https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path
dtlkg2path_name                = "datalake"
dtlkg2path_resource            = "directory"
