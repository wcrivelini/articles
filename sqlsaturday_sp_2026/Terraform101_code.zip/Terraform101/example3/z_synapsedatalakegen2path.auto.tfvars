#https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path
syndtlkg2path_name                = "syndatalake"
syndtlkg2path_resource            = "directory"
