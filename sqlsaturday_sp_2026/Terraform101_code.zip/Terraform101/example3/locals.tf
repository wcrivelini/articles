
locals {
  #TAGS
  tags = {
    company      = var.company
    project      = "${var.company}-${var.project}"
    costcenter   = var.costcenter
    environment  = var.environment
  }  

  #RESOURCE GROUP
  rg_name                 = lower(format("%s-%s-%s-%s-%s", var.shortprovider, var.shortlocation, var.environment, var.resourcegroup_identifier, var.resource_id))
  
  #KEY VAULT
  keyvault_name           = lower(format("%s-%s-%s-%s-%s", var.shortprovider, var.shortlocation, var.environment, var.keyvault_identifier, var.resource_id))          
  
  #COSMOSDB_ACCOUNT
  cosmosdb_accountname    = lower(format("%s-%s-%s-%s-%s", var.shortprovider, var.shortlocation, var.environment, var.cosmosdb_identifier, var.resource_id))
  
  #DATABRICKS
  databricks_name         = lower(format("%s-%s-%s-%s-%s", var.shortprovider, var.shortlocation, var.environment, var.databricks_identifier, var.resource_id))

  #DATA LAKE GEN2 (ACCOUNT)
  dtlkg2acct_name         = lower(format("%s%s%s%s%s", var.shortprovider, var.shortlocation, var.environment, var.dtlkg2_identifier, var.resource_id))

  #MS SQL SERVER
  sql_name                = lower(format("%s-%s-%s-%s-%s", var.shortprovider, var.shortlocation, var.environment, var.sql_identifier, var.resource_id))

  #STORAGE ACCOUNT
  stoacct_name            = lower(format("%s%s%s%s%s", var.shortprovider, var.shortlocation, var.environment, var.stoacct_identifier, var.resource_id))

  #SYNAPSE - DATA LAKE GEN2 (ACCOUNT)
  syndtlkg2acct_name      = lower(format("%s%s%s%s%s", var.shortprovider, var.shortlocation, var.environment, var.syndtlkg2_identifier, var.resource_id))

  #SYNAPSE WORKSPACE
  synapsewkspc_name       = lower(format("%s-%s-%s-%s-%s", var.shortprovider, var.shortlocation, var.environment, var.synapsewkspc_identifier, var.resource_id))

}
