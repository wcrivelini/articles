
resourcegroup_identifier= "rg"
location                = "brazilsouth"
shortlocation           = "brs"