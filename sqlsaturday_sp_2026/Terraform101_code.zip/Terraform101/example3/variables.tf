# ###############################################################
# variables related to TAGS
# ###############################################################
variable "company" {
    type  = string 
    description = "Company Name"
}

variable "project" {
    type  = string 
    description = "project name"
}

variable "costcenter" {
    type  = string 
    description = "cost center name"
}

variable "environment" {
    type  = string 
    description = "environment name"
}

variable "shortprovider"{
    type  = string 
    description = "cloud provider prefix"
}

variable "resource_id"{
    type  = string 
    description = "id of the resources to be deployed"
}



# ###############################################################
# variables related to RESOURCE GROUP
# ###############################################################
variable "resourcegroup_identifier" {
    type  = string 
    description = "identifier to resource group name"

}

variable "location" {
    type  = string 
    description = "code related to Azure Region"
}    
  

variable "shortlocation" {
    type  = string 
    description = "short code related to Azure Region"
} 


# ###############################################################
# variables related to COSMOS DB ACCOUNT
# ###############################################################
variable "keyvault_identifier" {
    type  = string 
    description = "identifier of Key Vault account"
}

variable "keyvault_encryption" {
    type  = string 
    description = "defines if disk encryption is enabled"
}

variable "keyvault_retention" {
    type  = string 
    description = "defines number of days of retention after delete"
}

variable "keyvault_purgeprotection" {
    type  = string 
    description = "defines if purge protection is enabled"
}

variable "keyvault_sku" {
    type  = string 
    description = "type of service. Options are standard & premium"
}


 




# ###############################################################
# variables related to COSMOS DB ACCOUNT
# ###############################################################
variable "cosmosdb_identifier" {
    type  = string 
    description = "identifier to Cosmos Db Account "
}

variable "cosmosdb_offer_type" {
    type  = string 
    description = "type Standard or Premium"
}  

variable "cosmosdb_kind" {
    type  = string 
    description = "type of API used. Documentation specifies valid values are GlobalDocumentDB and MongoDB only"
}  
 

variable "cosmosdb_consistency_level" {
  type  = string 
  description = "Consistency Level to use for this CosmosDB Account - \n Values are {BoundedStaleness, Eventual, Session, Strong or ConsistentPrefix} \n https://docs.microsoft.com/en-us/azure/cosmos-db/consistency-levels"
  # https://docs.microsoft.com/en-us/azure/cosmos-db/consistency-levels
 } 
 
#geo_location (replication)
variable "cosmosdb_replica_location" {
  type  = string 
  description = "Secondary region that will hold replicated data"
 }  
variable "cosmosdb_failover_priority" {
  type  = string 
  description = "Failover priority in case of crash. Must be a value equal or less than number of replicas minus 1"
 } 


# ###############################################################
# variables related to COSMOS DB DATABASE
# ###############################################################
variable "cosmosdb_dbsqlname" {
  type  = string 
  description = "name of the database (SQL API)"
}

variable "cosmosdb_throughput" {
  type  = string 
  description = "database throughput"
}
           

# ###############################################################
# variables related to DATABRICKS WORKSPACE
# ###############################################################
variable "databricks_identifier" {
  type  = string 
  description = "identifier to Databricks Workspace name"
}  

variable "databricks_sku" {
  type  = string 
  description = "type standard, premium or Trial"
}


# ###############################################################
# variables related to MS SQL SERVER
# ###############################################################
variable "sql_identifier" {
  type  = string 
  description = "identifier to Sql Server name"
}  

variable "sql_version" {
  type  = string 
  description = "MS SQL Server version"
}

variable "sql_login" {
  type  = string 
  description = "SQL login with SYSADMIN privileges"
}

variable "sql_loginpass" {
  type  = string 
  description = "Password"
 }  

variable "sql_tls" {
  type  = string 
  description = "TLS version"
 }  

variable "aadadmin_name" {
  type  = string
  description = "AAD login with SYSADMIN privileges. In this example, the AAD LOGIN that runs Terraform is the administrator of SYNAPSE WORKSAPCE and AZURE SQL DB"
 } 

variable "aadadmin_oid" {
  type  = string
  description = "Object Id correspondent to AAD login <aadadmin_name>"
 } 



# ###############################################################
# variables related to MS SQL SERVER DATABASE
# ###############################################################
variable "mssqldatabase_name" {
  type  = string 
  description = "MS SQL DATABASE name"
 }  

variable "mssqldatabase_collation" {
  type  = string
  description = "database collation"

 } 

variable "mssqldatabase_license" {
  type  = string
  description = "inform type of licensing to be used"

 } 

variable "mssqldatabase_maxsizegb" {
  type  = string
  description = "estabilish the max size allocated to the database (limit 4096 GB)"

 } 

variable "mssqldatabase_sku" {
  type  = string
  description = "database capacity"

 } 


# ###############################################################
# variables related to STORAGE ACCOUNT 
# ###############################################################
variable "stoacct_identifier" {
    type  =  string
    description = "identifier to Storage Account name"
}

variable "stoacct_tier" {
    type  =  string
    description = "Tier for Storage Account . Valid values are STANDARD and PREMIUM"
}

variable "stoacct_replication" {
    type  =  string
    description = "Type of replication for Storage Account . Valid values are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS"
}

variable "stoacct_kind" {
  type        = string 
  description = "Kind of Storage Account. Default is StoraV2, other values are BlobStorage, BlockBlobStorage, FileStorage, and Storage"
}

variable "stoacct_hierarchical_namespace" {
  type        = string 
  description = "Defines if Storage Account will use Hierarchical Namespace"
}



# ###############################################################
# variables related to STORAGE ACCOUNT CONTAINER
# ###############################################################
variable "stoacctcont_name" {
    type  =  string
    description = "Storage Account Container name"
}

variable "stoacctcont_access" {
    type  =  string
    description = "Container access type. Valid values are blob, container or private. Defaults to private."
}




# ###############################################################
# variables related to DATA LAKE GEN2 ACCOUNT (STORAGE ACCOUNT)
# https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path
# ###############################################################
variable "dtlkg2_identifier" {
    type  =  string
    description = "identifier to resource group name"
}

variable "dtlkg2_tier" {
    type  =  string
    description = "Tier for Storage Account . Valid values are STANDARD and PREMIUM"
}

variable "dtlkg2_replication" {
    type  =  string
    description = "Type of replication for Storage Account . Valid values are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS"
}


variable "dtlkg2_kind" {
  type        = string 
  description = "Kind of Storage Account. Default is StoraV2, other values are BlobStorage, BlockBlobStorage, FileStorage, and Storage"
}

variable "dtlkg2_hierarchical_namespace" {
  type        = string 
  description = "Defines if Storage Account will use Hierarchical Namespace"
}


# ###############################################################
# variables related to DATA LAKE GEN2 FILESYSTEM
# https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path
# ###############################################################
variable "dtlkg2filesystem_name" {
    type  =  string
    description = "Name of Data Lake Gen2"
}


# ###############################################################
# variables related to DATA LAKE GEN2 PATH
# https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path
# ###############################################################
variable "dtlkg2path_name" {
    type  =  string
    description = "Name of path in Data Lake Gen2"
}

variable "dtlkg2path_resource" {
    type  =  string
    description = "type of resource in Data Lake Gen2 path"
}



# ###############################################################
# variables related to SYNAPSE internal DATA LAKE GEN2 ACCOUNT (STORAGE ACCOUNT)
# https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path
# ###############################################################
variable "syndtlkg2_identifier" {
    type  =  string
    description = "identifier to resource group name"
}

variable "syndtlkg2_tier" {
    type  =  string
    description = "Tier for Storage Account . Valid values are STANDARD and PREMIUM"
}

variable "syndtlkg2_replication" {
    type  =  string
    description = "Type of replication for Storage Account . Valid values are LRS, GRS, RAGRS, ZRS, GZRS and RAGZRS"
}


variable "syndtlkg2_kind" {
  type        = string 
  description = "Kind of Storage Account. Default is StoraV2, other values are BlobStorage, BlockBlobStorage, FileStorage, and Storage"
}

variable "syndtlkg2_hierarchical_namespace" {
  type        = string 
  description = "Defines if Storage Account will use Hierarchical Namespace"
}


# ###############################################################
# variables related to SYNAPSE internal DATA LAKE GEN2 FILESYSTEM
# https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path
# ###############################################################
variable "syndtlkg2filesystem_name" {
    type  =  string
    description = "Name of Data Lake Gen2"
}


# ###############################################################
# variables related to DATA LAKE GEN2 PATH
# https://registry.terraform.io/providers/hashicorp/azurerm/latest/docs/resources/storage_data_lake_gen2_path
# ###############################################################
variable "syndtlkg2path_name" {
    type  =  string
    description = "Path created in Data Lake Gen2"
}
            
variable "syndtlkg2path_resource" {
    type  =  string
    description = "Path created in Data Lake Gen2"
}     


# ###############################################################
# variables related to SYNAPSE WORKSPACE
# ###############################################################
variable "synapsewkspc_identifier" {
  type  = string 
  description = "identifier of resource name."
}  

variable "synapsewkspc_sqladmin_login" {
  type  = string 
  description = "SQL admin login (SQL Pools)"
}

variable "synapsewkspc_sqladmin_pass" {
  type  = string 
  description = "SQL admin password (SQL Pools)"
 }  



variable "synapsewkspc_type" {
  type  = string
  description = "Type of Managed Service Identity used by Synapse Workspace. Valid values: SystemAssigned"
 } 

# ###############################################################
# variables related to SYNAPSE SQL POOL
# ###############################################################
variable "synsqlpool_name" {
  type  = string 
  description = "resource name."
}  

variable "synsqlpool_sku" {
  type  = string 
  description = "SKU for the SQL Pools"
}

variable "synsqlpool_mode" {
  type  = string 
  description = "Create mode for SQL Pools. Vaid values are Default, Recovery or PointInTimeRestore"
 }  
