cosmosdb_dbsqlname          = "tweedledum"
cosmosdb_throughput         = "400"
