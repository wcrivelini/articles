# cd example3
#../runTerraform.ps1

az login
#az account set --subscription $subscriptionID

$StartTime                   = Get-Date -Format 'yyyy-MM-dd-HH-mm-ss'
$fileName                    = "projectX__"
$operation                   = "_deploy_"
$extension                   = "plan"

$filePlan                    = "./" + $extension + "/" + $fileName +$operation + $StartTime + "." + $extension

 

terraform init 
terraform validate 
terraform plan  -out $filePlan
#terraform apply -auto-approve $filePlan 

$filePlan
