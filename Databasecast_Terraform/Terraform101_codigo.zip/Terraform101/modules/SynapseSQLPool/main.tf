resource "azurerm_synapse_sql_pool" "synapsesqlpool" {
  name                     = var.synsqlpool_name
  synapse_workspace_id     = var.synsqlpool_wrkspcid
  sku_name                 = var.synsqlpool_sku
  create_mode              = var.synsqlpool_mode
  geo_backup_policy_enabled= var.geo_backup_policy_enabled
  storage_account_type     = var.synsqlpool_stotype
}
