variable "synsqlpool_name" {
  type  = string 
  description = "resource name."
}  

variable "synsqlpool_wrkspcid" {
  type  = string 
  description = "id of the synapse workspace"
}

variable "synsqlpool_sku" {
  type  = string 
  description = "SKU for the SQL Pools"
}

variable "synsqlpool_mode" {
  type  = string 
  description = "Create mode for SQL Pools. Vaid values are Default, Recovery or PointInTimeRestore"
 }  

 variable "synsqlpool_stotype" {
  type  = string 
  description = "Define storage account redundancy. Values: LRS, GRS ou ZRS"
 } 

 variable "geo_backup_policy_enabled" {
  type  = string 
  description = "Define backup strategy. Values: if synsqlpool_stotype LRS then 'false' else 'true' "
 } 