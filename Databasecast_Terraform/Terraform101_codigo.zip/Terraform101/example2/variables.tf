# ###############################################################
# variables related to TAGS
# ###############################################################
variable "company" {
    type  = string 
    description = "company name"
    default = "WWI"
}

variable "project" {
    type  = string 
    description = "project name"
    default = "platdt"
}

variable "costcenter" {
    type  = string 
    description = "cost center name"
    default = "xyz"
}


variable "environment" {
    type  = string 
    description = "environment name"
    default = "dev"
}

variable "shortprovider"{
    type  = string 
    description = "cloud provider prefix"
    default = "az"    
}




# ###############################################################
# variables related to RESOURCE GROUP
# ###############################################################
variable "resourceIdentifier" {
    type  = string 
    description = "preffix to resource group name"
    default = "rg"
}

variable "location1" {
    type  = string 
    description = "code related to Azure Region"
    default = "brazilsouth"
}    
variable "location2" {
    type  = string 
    description = "code related to Azure Region"
    
    ###################################################################################
    # forçando a ocorrência de um erro para testar o comportamento do TERRAFORM
    #default = "brazilsoutheast"
    ###################################################################################

    
    # corrigindo o erro
    default = "chilecentral"
}    

variable "shortlocation1" {
    type  = string 
    description = "short code related to Azure Region"
    default = "brs"
}    
variable "shortlocation2" {
    type  = string 
    description = "short code related to Azure Region"
    default = "bse"
    #default = "clc"
}    
